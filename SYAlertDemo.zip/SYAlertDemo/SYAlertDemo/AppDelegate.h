//
//  AppDelegate.h
//  SYAlertDemo
//
//  Created by 张士玉 on 17/12/12.
//  Copyright © 2017年 张士玉. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

