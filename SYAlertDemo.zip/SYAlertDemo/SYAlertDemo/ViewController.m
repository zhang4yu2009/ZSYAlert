//
//  ViewController.m
//  SYAlertDemo
//
//  Created by 张士玉 on 17/12/12.
//  Copyright © 2017年 张士玉. All rights reserved.
//

#import "ViewController.h"
#import "UIAlertController+SYExtention.h"

@interface ViewController () //更新

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}
- (IBAction)btnClick:(id)sender {
    [UIAlertController showTitle:@"你好" msg:@"这是一个测试!" type:SURETYPE delegate:self complete:^(NSInteger tag) {
        NSLog(@"%ld", (long)tag);
        NSLog(@"%ld", (long)tag);
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
